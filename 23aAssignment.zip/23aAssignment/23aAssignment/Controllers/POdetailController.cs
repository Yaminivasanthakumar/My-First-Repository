﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using _23aAssignment.Models;

namespace _23aAssignment.Controllers
{
    public class POdetailController : ApiController
    {
        private assignmentEntities db = new assignmentEntities();

        // GET api/POdetail
        public IEnumerable<PODETAIL> GetPODETAILs()
        {
            var podetails = db.PODETAILs.Include(p => p.ITEM).Include(p => p.POMASTER);
            return podetails.AsEnumerable();
        }

        // GET api/POdetail/5
        public PODETAIL GetPODETAIL(string id,string id2)
        {
            PODETAIL podetail = db.PODETAILs.Find(id);
            if (podetail == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }

            return podetail;
        }

        // PUT api/POdetail/5
        public HttpResponseMessage PutPODETAIL(string id, PODETAIL podetail)
        {
            if (ModelState.IsValid)
            {
                db.Entry(podetail).State = EntityState.Modified;

                try
                {
                    db.SaveChanges();
                }
                catch (DbUpdateConcurrencyException)
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound);
                }

                return Request.CreateResponse(HttpStatusCode.OK);
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }

        // POST api/POdetail
        public HttpResponseMessage PostPODETAIL(PODETAIL podetail)
        {
            if (ModelState.IsValid)
            {
                db.PODETAILs.Add(podetail);
                db.SaveChanges();

                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, podetail);
                response.Headers.Location = new Uri(Url.Link("DefaultApi", new { id = podetail.PONO }));
                return response;
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }

        // DELETE api/POdetail/5
        public HttpResponseMessage DeletePODETAIL(string id)
        {
            PODETAIL podetail = db.PODETAILs.Find(id);
            if (podetail == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            db.PODETAILs.Remove(podetail);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            return Request.CreateResponse(HttpStatusCode.OK, podetail);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}