﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using _23aAssignment.Models;

namespace _23aAssignment.Controllers
{
    public class POmasterController : ApiController
    {
        private assignmentEntities db = new assignmentEntities();

        // GET api/POmaster
        public IEnumerable<POMASTER> GetPOMASTERs()
        {
            var pomasters = db.POMASTERs.Include(p => p.SUPPLIER);
            return pomasters.AsEnumerable();
        }

        // GET api/POmaster/5
        public POMASTER GetPOMASTER(string id)
        {
            POMASTER pomaster = db.POMASTERs.Find(id);
            if (pomaster == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }

            return pomaster;
        }

        // PUT api/POmaster/5
        public HttpResponseMessage PutPOMASTER(string id, POMASTER pomaster)
        {
            if (ModelState.IsValid)
            {
                db.Entry(pomaster).State = EntityState.Modified;

                try
                {
                    db.SaveChanges();
                }
                catch (DbUpdateConcurrencyException)
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound);
                }

                return Request.CreateResponse(HttpStatusCode.OK);
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }

        // POST api/POmaster
        public HttpResponseMessage PostPOMASTER(POMASTER pomaster)
        {
            if (ModelState.IsValid)
            {
                db.POMASTERs.Add(pomaster);
                db.SaveChanges();

                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, pomaster);
                response.Headers.Location = new Uri(Url.Link("DefaultApi", new { id = pomaster.PONO }));
                return response;
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }

        // DELETE api/POmaster/5
        public HttpResponseMessage DeletePOMASTER(string id)
        {
            POMASTER pomaster = db.POMASTERs.Find(id);
            if (pomaster == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            db.POMASTERs.Remove(pomaster);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            return Request.CreateResponse(HttpStatusCode.OK, pomaster);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}