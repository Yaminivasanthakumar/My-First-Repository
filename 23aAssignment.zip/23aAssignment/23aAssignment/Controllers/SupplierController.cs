﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using _23aAssignment.Models;

namespace _23aAssignment.Controllers
{
    public class SupplierController : ApiController
    {
        private assignmentEntities db = new assignmentEntities();

        // GET api/Supplier
        public IEnumerable<SUPPLIER> GetSUPPLIERs()
        {
            return db.SUPPLIERs.AsEnumerable();
        }

        // GET api/Supplier/5
        public SUPPLIER GetSUPPLIER(string id)
        {
            SUPPLIER supplier = db.SUPPLIERs.Find(id);
            if (supplier == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }

            return supplier;
        }

        // PUT api/Supplier/5
        public HttpResponseMessage PutSUPPLIER(string id, SUPPLIER supplier)
        {
            if (ModelState.IsValid)
            {
                db.Entry(supplier).State = EntityState.Modified;

                try
                {
                    db.SaveChanges();
                }
                catch (DbUpdateConcurrencyException)
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound);
                }

                return Request.CreateResponse(HttpStatusCode.OK);
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }

        // POST api/Supplier
        public HttpResponseMessage PostSUPPLIER(SUPPLIER supplier)
        {
            if (ModelState.IsValid)
            {
                db.SUPPLIERs.Add(supplier);
                db.SaveChanges();

                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, supplier);
                response.Headers.Location = new Uri(Url.Link("DefaultApi", new { id = supplier.SUPLNO }));
                return response;
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }

        // DELETE api/Supplier/5
        public HttpResponseMessage DeleteSUPPLIER(string id)
        {
            SUPPLIER supplier = db.SUPPLIERs.Find(id);
            if (supplier == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            db.SUPPLIERs.Remove(supplier);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            return Request.CreateResponse(HttpStatusCode.OK, supplier);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}