﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using System.Net.Http;
using _23aMVC;
using _23aMVC.Models;
namespace _23mvcassignment.Controllers
{
    public class ItemController : Controller
    {
        //
        // GET: /Item/

        public ActionResult Index()
        {
            IEnumerable<ITEM> ItemlList;

            HttpResponseMessage response = Globalvarialbe.webapiclient.GetAsync("Item").Result;
            ItemlList = response.Content.ReadAsAsync<IEnumerable<ITEM>>().Result;

            return View(ItemlList);
        }
        public ActionResult add()
        {


            return View();
        }
        [HttpPost]
        public ActionResult add(ITEM s)
        {

            HttpResponseMessage response = Globalvarialbe.webapiclient.PostAsJsonAsync("Item", s).Result;
            return RedirectToAction("Index");
        }

        public ActionResult edit(string id)
        {
            ITEM ItemList;
            //id = "1";
            HttpResponseMessage response = Globalvarialbe.webapiclient.GetAsync("Item/" + id).Result;
            ItemList = response.Content.ReadAsAsync<ITEM>().Result;
            return View(ItemList);
        }
        [HttpPost]
        public ActionResult edit(string id, ITEM I)
        {
            HttpResponseMessage response = Globalvarialbe.webapiclient.PutAsJsonAsync("Item/" + id, I).Result;
            return RedirectToAction("Index");

        }

        public ActionResult details(string id)
        {
            ITEM ItemlList;
            HttpResponseMessage response = Globalvarialbe.webapiclient.GetAsync("Item/" + id).Result;
            ItemlList = response.Content.ReadAsAsync<ITEM>().Result;
            return View(ItemlList);
        }

        public ActionResult delete(string id)
        {
            ITEM ItemlList;
            HttpResponseMessage response = Globalvarialbe.webapiclient.GetAsync("Item/" + id).Result;
            ItemlList = response.Content.ReadAsAsync<ITEM>().Result;
            return View(ItemlList);

        }

        [HttpPost]
        public ActionResult delete(string id, ITEM I)
        {
            HttpResponseMessage response = Globalvarialbe.webapiclient.DeleteAsync("Item/" + id).Result;
            return RedirectToAction("Index");
        }
    }
}
