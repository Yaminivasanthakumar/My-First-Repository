﻿using _23aMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace _23aMVC.Controllers
{
    public class POdetailController : Controller
    {
        //
        // GET: /POdetail/

        public ActionResult Index()
        {
            IEnumerable<PODETAIL> POMASTERlList;

            HttpResponseMessage response = Globalvarialbe.webapiclient.GetAsync("POdetail").Result;
            POMASTERlList = response.Content.ReadAsAsync<IEnumerable<PODETAIL>>().Result;

            return View(POMASTERlList);
        }
        public ActionResult add()
        {


            return View();
        }
        [HttpPost]
        public ActionResult add(PODETAIL s)
        {

            HttpResponseMessage response = Globalvarialbe.webapiclient.PostAsJsonAsync("POdetail", s).Result;
            return RedirectToAction("Index");
        }

        public ActionResult edit(string id)
        {
            PODETAIL POMASTERlList;

            HttpResponseMessage response = Globalvarialbe.webapiclient.GetAsync("POdetail/" + id).Result;
            POMASTERlList = response.Content.ReadAsAsync<PODETAIL>().Result;
            return View(POMASTERlList);
        }
        [HttpPost]
        public ActionResult edit(string id, PODETAIL I)
        {
            HttpResponseMessage response = Globalvarialbe.webapiclient.PutAsJsonAsync("POdetail/" + id, I).Result;
            return RedirectToAction("Index");

        }

        public ActionResult details(string id)
        {
            PODETAIL POMASTERlList;
            HttpResponseMessage response = Globalvarialbe.webapiclient.GetAsync("POdetail/" + id).Result;
            POMASTERlList = response.Content.ReadAsAsync<PODETAIL>().Result;
            return View(POMASTERlList);
        }

        public ActionResult delete(string id)
        {
            PODETAIL POMASTERlList;
            HttpResponseMessage response = Globalvarialbe.webapiclient.GetAsync("POdetail/" + id).Result;
            POMASTERlList = response.Content.ReadAsAsync<PODETAIL>().Result;
            return View(POMASTERlList);

        }

        [HttpPost]
        public ActionResult delete(string id, PODETAIL I)
        {
            HttpResponseMessage response = Globalvarialbe.webapiclient.DeleteAsync("POdetail/" + id).Result;
            return RedirectToAction("Index");
        }

    }
}
