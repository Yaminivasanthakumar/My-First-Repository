﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net.Http;
using _23aMVC;
using _23aMVC.Models;
namespace _23mvcassignment.Controllers
{
    public class POMASTERController : Controller
    {
        //
        // GET: /POMASTER/

        public ActionResult Index()
        {
            IEnumerable<POMASTER> POMASTERlList;

            HttpResponseMessage response = Globalvarialbe.webapiclient.GetAsync("POMASTER").Result;
            POMASTERlList = response.Content.ReadAsAsync<IEnumerable<POMASTER>>().Result;

            return View(POMASTERlList);
        }
        public ActionResult add()
        {


            return View();
        }
        [HttpPost]
        public ActionResult add(POMASTER s)
        {

            HttpResponseMessage response = Globalvarialbe.webapiclient.PostAsJsonAsync("POmaster", s).Result;
            return RedirectToAction("Index");
        }

        public ActionResult edit(string id)
        {
            POMASTER POMASTERlList;

            HttpResponseMessage response = Globalvarialbe.webapiclient.GetAsync("POmaster/" + id).Result;
            POMASTERlList = response.Content.ReadAsAsync<POMASTER>().Result;
            return View(POMASTERlList);
        }
        [HttpPost]
        public ActionResult edit(string id, POMASTER I)
        {
            HttpResponseMessage response = Globalvarialbe.webapiclient.PutAsJsonAsync("POmaster/" + id, I).Result;
            return RedirectToAction("Index");

        }

        public ActionResult details(string id)
        {
            POMASTER POMASTERlList;
            HttpResponseMessage response = Globalvarialbe.webapiclient.GetAsync("POmaster/" + id).Result;
            POMASTERlList = response.Content.ReadAsAsync<POMASTER>().Result;
            return View(POMASTERlList);
        }

        public ActionResult delete(string id)
        {
            POMASTER POMASTERlList;
            HttpResponseMessage response = Globalvarialbe.webapiclient.GetAsync("POmaster/" + id).Result;
            POMASTERlList = response.Content.ReadAsAsync<POMASTER>().Result;
            return View(POMASTERlList);

        }

        [HttpPost]
        public ActionResult delete(string id, POMASTER I)
        {
            HttpResponseMessage response = Globalvarialbe.webapiclient.DeleteAsync("POmaster/" + id).Result;
            return RedirectToAction("Index");
        }

    }
}
