﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net.Http;
using _23aMVC;
using _23aMVC.Models;


namespace _23mvcassignment.Controllers
{
    public class SupplierController : Controller
    {
        //
        // GET: /Supplier/

        public ActionResult Index()
        {
            IEnumerable<SUPPLIER> suplList;

            HttpResponseMessage response = Globalvarialbe.webapiclient.GetAsync("Supplier").Result;
            suplList = response.Content.ReadAsAsync<IEnumerable<SUPPLIER>>().Result;

            return View(suplList);
        }

        public ActionResult add()
        {


            return View();
        }
        [HttpPost]
        public ActionResult add(SUPPLIER s)
        {

            HttpResponseMessage response = Globalvarialbe.webapiclient.PostAsJsonAsync("Supplier", s).Result;
            return RedirectToAction("Index");
        }

        public ActionResult edit(string id)
        {
            SUPPLIER suplList;
            //id = "1";
            HttpResponseMessage response = Globalvarialbe.webapiclient.GetAsync("Supplier/" + id).Result;
            suplList = response.Content.ReadAsAsync<SUPPLIER>().Result;
            return View(suplList);
        }
        [HttpPost]
        public ActionResult edit(string id, SUPPLIER s)
        {
            HttpResponseMessage response = Globalvarialbe.webapiclient.PutAsJsonAsync("Supplier/" + id, s).Result;
            return RedirectToAction("Index");

        }

        public ActionResult details(string id)
        {
            SUPPLIER suplList;
            HttpResponseMessage response = Globalvarialbe.webapiclient.GetAsync("Supplier/" + id).Result;
            suplList = response.Content.ReadAsAsync<SUPPLIER>().Result;
            return View(suplList);
        }

        public ActionResult delete(string id)
        {
            SUPPLIER suplList;
            HttpResponseMessage response = Globalvarialbe.webapiclient.GetAsync("Supplier/" + id).Result;
            suplList = response.Content.ReadAsAsync<SUPPLIER>().Result;
            return View(suplList);

        }

        [HttpPost]
        public ActionResult delete(string id, SUPPLIER s)
        {
            HttpResponseMessage response = Globalvarialbe.webapiclient.DeleteAsync("Supplier/" + id).Result;
            return RedirectToAction("Index");
        }
    }
}
