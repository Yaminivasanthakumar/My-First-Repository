﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;

namespace _23aMVC
{
    public static class Globalvarialbe
    {
        public static HttpClient webapiclient = new HttpClient();

        static Globalvarialbe()
        {
            webapiclient.BaseAddress = new Uri("http://localhost:61694/api/");
            webapiclient.DefaultRequestHeaders.Clear();
            webapiclient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

    }
}