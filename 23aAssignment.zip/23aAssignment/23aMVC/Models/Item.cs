﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace _23aMVC.Models
{

    public partial class ITEM
    {
        public ITEM()
        {
            this.PODETAILs = new HashSet<PODETAIL>();
        }

        public string ITCODE { get; set; }
        public string ITDESC { get; set; }
        public Nullable<decimal> ITRATE { get; set; }

        public virtual ICollection<PODETAIL> PODETAILs { get; set; }
    }
}