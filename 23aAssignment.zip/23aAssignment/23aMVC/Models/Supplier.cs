﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace _23aMVC.Models
{
    public partial class SUPPLIER
    {
        public SUPPLIER()
        {
            this.POMASTERs = new HashSet<POMASTER>();
        }

        public string SUPLNO { get; set; }
        public string SUPLNAME { get; set; }
        public string SUPLADDR { get; set; }

        public virtual ICollection<POMASTER> POMASTERs { get; set; }
    }
}