﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Helloservice
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        public string SayHello(string value)
        {
            string timenow = DateTime.Now.ToString("mm/dd/yyyy HH:mm:ss");
            int time = int.Parse(timenow.Substring(11, 2));
            string wishes = " ";
            if (time < 12 || time == 0)
            {

                wishes = "good morning";

            }
            else if (time >= 12 || time <= 15)
            {
                wishes = "good afternoon";
            }
            else if (time > 15 || time < 20)
            {

                wishes = "good evening";
            }

            return string.Format("{0} {1}", wishes, value);
        }

        public string TodayProgram(string value)
        {

            DateTime dt = DateTime.Now;
            string day = dt.DayOfWeek.ToString();
            string Wishes = " ";
            if (day == "Monday" || day == "Tuesday" || day == "Wednesday" || day == "Thursday" || day == "Friday")
            {

                Wishes = "Enjoy Working day";

            }
            else
            {

                Wishes = "Happy weekend";
            
            }

            return string.Format("{0} {1}", Wishes,value);
        }
        public class jobs
        {
        public string jobname;
        public string rolename;
        
        }
        public List<jobs> OpeningJobs()
        {
            List<jobs> jobslist = new List<jobs>();
            jobslist.Add(new jobs { jobname = "Cognizant", rolename = "Developer" });
            jobslist.Add(new jobs { jobname = "TCS", rolename = "Tester" });
            jobslist.Add(new jobs { jobname = "Wipro", rolename = "Manager" });
            jobslist.Add(new jobs { jobname = "Infosys", rolename = "Manager" });
            jobslist.Add(new jobs { jobname = "TechM", rolename = "Developer" });


            return jobslist;
        
        }

        public List<jobs> choosebyrole(string value)
        { 
         List<jobs> jobslist = new List<jobs>();
            jobslist.Add(new jobs { jobname = "Cognizant", rolename = "Developer" });
            jobslist.Add(new jobs { jobname = "TCS", rolename = "Tester" });
            jobslist.Add(new jobs { jobname = "Wipro", rolename = "Manager" });
            jobslist.Add(new jobs { jobname = "Infosys", rolename = "Manager" });
            jobslist.Add(new jobs { jobname = "TechM", rolename = "Developer" });

            var query1 = from t in jobslist
                         where t.rolename == value
                         select t;
            List<jobs> l1 = new List<jobs>();
            foreach (var i in query1)
            {

               
                l1.Add(i);
               
            }
            return l1;
        }

    }
}
