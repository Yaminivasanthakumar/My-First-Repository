﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace Helloservicehost
{
    class Program
    {
        static void Main()
        {
            using (ServiceHost host = new ServiceHost(typeof(Helloservice.Service1)))
            {

                host.Open();
                Console.WriteLine("Host opens {0}",DateTime.Now);
                Console.ReadLine();
            }
        }
    }
}
