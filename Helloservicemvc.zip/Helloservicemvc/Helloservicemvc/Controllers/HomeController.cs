﻿using Helloservicemvc.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WCF_MVCapplication.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Default1/

        public ActionResult Index()
        {

            return View();
        }

        [HttpPost]
        public ActionResult Index(string text, string submit)
        {
            Helloservicemvc.ServiceReference1.Service1Client g = new Helloservicemvc.ServiceReference1.Service1Client();
            g.Open();

            if (submit == "Button1")
            {
                string output = g.SayHello(text);
                string outpu2 = g.TodayProgram(text);
                ViewBag.user1 = output;
                ViewBag.user2 = outpu2;

            }

            return View();
        }

        public ActionResult jobopening()
        {
            Helloservicemvc.ServiceReference1.Service1Client g = new Helloservicemvc.ServiceReference1.Service1Client();
            g.Open();
         List<Service1jobs> jobopenings= g.OpeningJobs().ToList();

         return View(jobopenings);
        
        }

        public ActionResult jobopeningbyrole(string text)
        {
            Helloservicemvc.ServiceReference1.Service1Client g = new Helloservicemvc.ServiceReference1.Service1Client();
            g.Open();
            List<Service1jobs> t = new List<Service1jobs>();

            t = g.choosebyrole(text).ToList();
  
            return View(t);
           
        
        
        }
    }
}