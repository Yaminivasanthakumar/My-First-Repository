﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Twitter.Model;

namespace Twitter.Controllers
{
    public class PersonController : Controller
    {
        private assignmentEntities1 db = new assignmentEntities1();
       
     
        //
        // GET: /Person/

        public ActionResult Index()
        {
            return View("Login");
        }
        
        public ActionResult Userpage( )
        {

            
            string id = @Session["userid"].ToString();
            List<Tweet> t = new List<Tweet>();
            var query = from t1 in db.Tweets
                        join t2 in db.FOLLOWINGs
                        on t1.user_id equals t2.following_id 
                        where t2.user_id == id
                        select t1;

            foreach (var i in query)
            {
                t.Add(i);
            }
            return View("Userpage",t);
        }
        //
        // GET: /Person/Details/5
        [HttpPost]
        public ActionResult Login(Person p)
        {
            Person person = db.Persons.Find(p.user_id);
    
            if (person == null)
            {
                ViewBag.Errmsg1 = "Userid doesnot Exists.Sign up to Continue!!";
                ModelState.Clear();
                return View("Login");
            }

            else
            {
                if ((person.passwordHash == p.passwordHash)&&(person.user_id ==p.user_id) && (person.active==true))
                {
                    Session["username"] = person.fullName;
                    Session["userid"] = person.user_id;
                    
                    return RedirectToAction("Userpage");
                }
                else {
                    ViewBag.Errmsg1 = "username/Password doesnot match.Please verify and try again";
                    ModelState.Clear();
                    return View("Login");
                }
            
            }
           
         
        }

        //
        // GET: /Person/Create

        public ActionResult Signup()
        {
            return View();
        }

        //
        // POST: /Person/Create

        [HttpPost]
        public ActionResult Signup(Person person)
        {
            if (ModelState.IsValid)
            {
              
                    person.joined = DateTime.Now;
                    person.active = true;
               
                db.Persons.Add(person);
                db.SaveChanges();
              
            }

            return RedirectToAction("Index");
        }


        public ActionResult Followers()
        {

            string userid = @Session["userid"].ToString();
            
            var query = from t in db.Persons
                       from t3 in ( from t2 in db.FOLLOWINGs
                        where  t2.following_id==userid select t2)
                        
                        where  t.user_id == t3.user_id 
                        && t.active==true
                        
                        select t;

            List<Person> list = new List<Person>();
            foreach (var i in query)
            {
                list.Add(i);
            
            
            }

            return View (list);
        }

        public ActionResult  Following()
        {

            string userid = @Session["userid"].ToString();

            var query = from t in db.Persons
                        from t3 in
                            (from t2 in db.FOLLOWINGs
                             where t2.user_id == userid
                             select t2)

                        where t.user_id == t3.following_id
                         && t.active == true
                        select t;

            List<Person> list = new List<Person>();
            foreach (var i in query)
            {
                list.Add(i);


            }

            return View(list);
        }






        public ActionResult Signout()
        {

            FormsAuthentication.SignOut();
            Session.Abandon(); // it will clear the session at the end of request
            return RedirectToAction("Index");
        }

        

        public ActionResult Profile(string id)
        {
            Person person = db.Persons.Find(id);
            if (person == null)
            {
                return HttpNotFound();
            }
            return View(person);
        }

        //
        // POST: /Person/Edit/5

        [HttpPost]
        public ActionResult Profile(Person person, string newpassword, string button)
        {

            if (button == "Delete") {

                //Person p = db.Persons.Find(person.user_id);
                person.active = false;
               // db.Persons.Remove(p);
                db.Entry(person).State = EntityState.Modified;
               
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {


                if (ModelState.IsValid)
                {


                    if (newpassword.Length > 0)
                    {
                        person.passwordHash = newpassword;
                    }
                    db.Entry(person).State = EntityState.Modified;
                    db.SaveChanges();
                    ViewBag.Errmsg2 = "Details Updated Successfully";
                    return View();

                }
                return View();
            }
        }

        public ActionResult followadd(string id)
        {
           
               FOLLOWING flist=new FOLLOWING();
               flist.user_id = Session["userid"].ToString();
                flist.following_id = id;

                FOLLOWING f = db.FOLLOWINGs.Add(flist);
                db.SaveChanges();
               
           
            return RedirectToAction("Userpage");
        }

        public ActionResult searchresult()
        {
            List<Person> flist =(List<Person>) TempData["list"];
            return View(flist);
        }

       
        public ActionResult Delete(Person p)
        {
            Person person = db.Persons.Find(p.user_id);
            db.Persons.Remove(person);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
       
        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}