﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Twitter.Model;

namespace Twitter.Controllers
{
    public class TweetController : Controller
    {
        private assignmentEntities1 db = new assignmentEntities1();

       

        public ActionResult Index()
        {
            var tweets = db.Tweets.Include(t => t.Person);
            return View(tweets.ToList());
        }

        

        public ActionResult Details(int id = 0)
        {
          
                Tweet tweet = db.Tweets.Find(id);
            if (tweet == null)
            {
                return HttpNotFound();
            }
            return View(tweet);
        }

      

        [HttpPost]
        public ActionResult Tweetupdate(string Tweet, string button, string text)
        {
            if (button == "Update")
            {
                Tweet t = new Tweet();
                t.message = Tweet;
                t.user_id = @Session["userid"].ToString();
                t.Created = DateTime.Now;

                if (ModelState.IsValid)
                {
                    db.Tweets.Add(t);
                    db.SaveChanges();

                }
                return RedirectToAction("Userpage", "Person");
            }
            else if (button == "Search")
            {
                string userid = @Session["userid"].ToString();
                int count = (from t in db.FOLLOWINGs
                             where t.user_id == userid
                             select t).Count();
                if (count == 0)
                {
                    var query1 = from t in db.Persons
                                 where ((t.user_id.Contains(text) || t.fullName.Contains(text)) && (t.user_id != userid))
                                 select t;

                    List<Person> list1 = new List<Person>();
                    foreach (var i in query1)
                    {

                        
                        list1.Add(new Person { user_id = i.user_id, fullName = i.fullName, email = i.email, joined = i.joined })
     ;


                    }
                    TempData["list"] = list1;

                }
                else
                {
                    var query1 = (from t1 in
                                      (from t in db.Persons
                                       where (t.user_id.Contains(text) || t.fullName.Contains(text)) && (t.user_id != userid)
                                       select t)
                                  select t1);
                      var query2=          (from t2 in
                                    (from t3 in db.FOLLOWINGs where t3.user_id == userid select t3) select t2).Distinct();

                      int count2 = query2.Count();



                         
                      List<Person> list1 = new List<Person>();

                

                      foreach (var j in query1)
                      {
                          int c = 0;
                          foreach (var i in query2)
                          {

                              if (i.following_id != j.user_id)
                              {
                                  c = c + 1;


                              }
                          }
                          if (c == count2)
                          {
                              list1.Add(new Person { user_id = j.user_id, fullName = j.fullName, email = j.email, joined = j.joined });
                          }

                          }                    
                      TempData["list"] = list1;
               
                }
               
                return RedirectToAction("searchresult", "Person", TempData["list"]);              
            }
            else 
                {
                return RedirectToAction("Userpage", "Person");
            
            }
            
        }

        

        [HttpPost]
        public ActionResult Edit(string Tweet)
        {

            Tweet t = new Tweet();
            t.message = Tweet;
            t.user_id = @Session["userid"].ToString();
            t.Created = DateTime.Now;

            if (ModelState.IsValid)
            {
                db.Entry(t).State = EntityState.Modified;
                db.SaveChanges();
               
            }
            return RedirectToAction("Userpage");
        }

        //
        // GET: /Tweet/Delete/5

        public ActionResult Delete(int id = 0)
        {
            Tweet tweet = db.Tweets.Find(id);
            if (tweet == null)
            {
                return HttpNotFound();
            }
            return View(tweet);
        }

        //
        // POST: /Tweet/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            Tweet tweet = db.Tweets.Find(id);
            db.Tweets.Remove(tweet);
            db.SaveChanges();
            return RedirectToAction("Index");
        }


        public ActionResult Mytweets()
        { 
         string  user_id = @Session["userid"].ToString();
         var query = from t in db.Tweets
                     where t.user_id == user_id
                     select t;
          List<Tweet> tlist=new List<Tweet>();
         foreach(var i in query)
         {
         tlist.Add(i);
         
         }
         return View(tlist);
        
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}